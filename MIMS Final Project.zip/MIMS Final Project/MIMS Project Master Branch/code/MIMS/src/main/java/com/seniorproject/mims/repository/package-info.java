/**
 * Spring Data JPA repositories.
 */
package com.seniorproject.mims.repository;
