/**
 * Data Transfer Objects.
 */
package com.seniorproject.mims.service.dto;
