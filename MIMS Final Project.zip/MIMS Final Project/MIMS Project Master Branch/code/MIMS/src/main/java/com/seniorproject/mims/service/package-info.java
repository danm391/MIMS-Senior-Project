/**
 * Service layer beans.
 */
package com.seniorproject.mims.service;
