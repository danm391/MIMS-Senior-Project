/**
 * JPA domain objects.
 */
package com.seniorproject.mims.domain;
