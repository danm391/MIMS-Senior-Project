/**
 * View Models used by Spring MVC REST controllers.
 */
package com.seniorproject.mims.web.rest.vm;
