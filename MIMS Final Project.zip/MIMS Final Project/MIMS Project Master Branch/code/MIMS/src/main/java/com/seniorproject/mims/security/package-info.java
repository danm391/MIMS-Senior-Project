/**
 * Spring Security configuration.
 */
package com.seniorproject.mims.security;
