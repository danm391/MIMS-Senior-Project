export * from './public-tip.component'
export * from './public-tip.route'
export * from './public-tip.module'
