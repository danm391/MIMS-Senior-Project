export * from './single-detail.component'
export * from './single-detail.route'
export * from './single-detail.module'
