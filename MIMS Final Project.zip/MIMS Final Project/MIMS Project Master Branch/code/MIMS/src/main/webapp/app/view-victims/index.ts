export * from './view-victims.component';
export * from './view-victims.route';
export * from './view-victims.module';
