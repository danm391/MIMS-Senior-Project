export * from './victim-photo.model';
export * from './victim-photo-popup.service';
export * from './victim-photo.service';
export * from './victim-photo-dialog.component';
export * from './victim-photo-delete-dialog.component';
export * from './victim-photo-detail.component';
export * from './victim-photo.component';
export * from './victim-photo.route';
