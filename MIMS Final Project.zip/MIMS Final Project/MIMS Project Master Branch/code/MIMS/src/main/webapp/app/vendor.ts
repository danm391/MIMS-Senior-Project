/* after changing this file run 'yarn run webpack:build' */
/* tslint:disable */
import '../content/css/vendor.css';
// jhipster-needle-add-element-to-vendor - JHipster will add new menu items here
